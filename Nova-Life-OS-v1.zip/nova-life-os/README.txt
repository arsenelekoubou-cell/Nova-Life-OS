NOVA LIFE OS — VERSION 1

Contenu :
- roue de la vie interactive avec 10 domaines, dont la vie spirituelle ;
- notes de 1 à 10 ;
- objectifs à court, moyen et long terme ;
- prochaine action et date de réévaluation ;
- sauvegarde automatique sur l'appareil ;
- export et import JSON ;
- fonctionnement hors connexion après la première ouverture ;
- installation possible sur l'écran d'accueil iPhone et iPad après hébergement HTTPS.

IMPORTANT
Ouvrir index.html directement permet de tester l'interface, mais l'installation PWA et le service worker exigent un hébergement HTTPS.

Déploiement simple :
1. Décompresser le dossier.
2. Publier tous les fichiers sur Netlify, GitHub Pages, Vercel ou Cloudflare Pages.
3. Ouvrir l'adresse obtenue dans Safari sur iPhone/iPad.
4. Partager > Sur l'écran d'accueil > Ajouter.

Les données de cette version restent locales à chaque appareil.
Pour une synchronisation iPhone/iPad, une prochaine version devra ajouter un compte utilisateur et une base de données sécurisée.
